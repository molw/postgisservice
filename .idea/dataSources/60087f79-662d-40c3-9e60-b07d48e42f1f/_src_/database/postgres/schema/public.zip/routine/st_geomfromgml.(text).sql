CREATE FUNCTION st_geomfromgml (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT _ST_GeomFromGML($1, 0)
$$
