CREATE FUNCTION st_transform (rast raster, srid integer, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125, scalex double precision DEFAULT 0, scaley double precision DEFAULT 0) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT _st_gdalwarp($1, $3, $4, $2, $5, $6) 
$$
