CREATE FUNCTION st_valuepercent (rastertable text, rastercolumn text, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT value, percent FROM _st_valuecount($1, $2, 1, TRUE, $3, $4) 
$$
