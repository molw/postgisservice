CREATE FUNCTION st_pointfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'POINT'
	THEN ST_GeomFromText($1)
	ELSE NULL END
	
$$
