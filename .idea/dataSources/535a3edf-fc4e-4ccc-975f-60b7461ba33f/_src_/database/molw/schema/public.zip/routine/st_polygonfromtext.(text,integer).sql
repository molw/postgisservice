CREATE FUNCTION st_polygonfromtext (text, integer) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_PolyFromText($1, $2)
$$
