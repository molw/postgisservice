CREATE FUNCTION get_proj4_from_srid (integer) RETURNS text
	LANGUAGE plpgsql
AS $$
BEGIN
	RETURN proj4text::text FROM spatial_ref_sys WHERE srid= $1;
END;
$$
