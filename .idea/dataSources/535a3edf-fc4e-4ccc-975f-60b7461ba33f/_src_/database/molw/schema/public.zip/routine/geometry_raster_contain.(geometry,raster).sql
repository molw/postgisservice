CREATE FUNCTION geometry_raster_contain (geometry, raster) RETURNS boolean
	LANGUAGE sql
AS $$
select $1 ~ $2::geometry
$$
