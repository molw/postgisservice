CREATE FUNCTION st_approxcount (rastertable text, rastercolumn text, nband integer, sample_percent double precision) RETURNS bigint
	LANGUAGE sql
AS $$
 SELECT _st_count($1, $2, $3, TRUE, $4) 
$$
