CREATE FUNCTION lockrow (text, text, text) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00'); 
$$
