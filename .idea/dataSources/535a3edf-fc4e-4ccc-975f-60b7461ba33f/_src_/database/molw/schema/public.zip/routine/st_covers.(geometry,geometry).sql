CREATE FUNCTION st_covers (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 ~ $2 AND _ST_Covers($1,$2)
$$
