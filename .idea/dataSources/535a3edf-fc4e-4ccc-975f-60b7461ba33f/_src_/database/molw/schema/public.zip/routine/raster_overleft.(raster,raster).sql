CREATE FUNCTION raster_overleft (raster, raster) RETURNS boolean
	LANGUAGE sql
AS $$
select $1::geometry &< $2::geometry
$$
