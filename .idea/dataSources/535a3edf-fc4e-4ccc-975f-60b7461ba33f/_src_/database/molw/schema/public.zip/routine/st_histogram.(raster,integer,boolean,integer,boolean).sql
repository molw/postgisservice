CREATE FUNCTION st_histogram (rast raster, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT min, max, count, percent FROM _st_histogram($1, $2, $3, 1, $4, NULL, $5) 
$$
