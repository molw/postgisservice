CREATE FUNCTION st_patchn (geometry, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN ST_GeometryN($1, $2)
	ELSE NULL END
	
$$
