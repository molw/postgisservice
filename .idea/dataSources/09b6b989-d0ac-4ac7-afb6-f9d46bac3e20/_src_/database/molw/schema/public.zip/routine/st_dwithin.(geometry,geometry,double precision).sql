CREATE FUNCTION st_dwithin (geom1 geometry, geom2 geometry, double precision) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && ST_Expand($2,$3) AND $2 && ST_Expand($1,$3) AND _ST_DWithin($1, $2, $3)
$$
