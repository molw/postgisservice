CREATE FUNCTION st_mlinefromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'MULTILINESTRING'
	THEN ST_GeomFromText($1)
	ELSE NULL END
	
$$
