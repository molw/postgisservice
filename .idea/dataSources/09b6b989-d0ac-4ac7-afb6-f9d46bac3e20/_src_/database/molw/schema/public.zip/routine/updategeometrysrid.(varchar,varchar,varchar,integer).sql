CREATE FUNCTION updategeometrysrid (character varying, character varying, character varying, integer) RETURNS text
	LANGUAGE plpgsql
AS $$
DECLARE
	ret  text;
BEGIN
	SELECT UpdateGeometrySRID('',$1,$2,$3,$4) into ret;
	RETURN ret;
END;
$$
