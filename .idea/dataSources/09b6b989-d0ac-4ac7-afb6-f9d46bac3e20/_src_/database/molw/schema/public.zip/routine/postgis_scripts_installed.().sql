CREATE FUNCTION postgis_scripts_installed () RETURNS text
	LANGUAGE sql
AS $$
 SELECT '2.2.4'::text || ' r' || 15258::text AS version 
$$
