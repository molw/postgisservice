CREATE FUNCTION postgis_scripts_build_date () RETURNS text
	LANGUAGE sql
AS $$
SELECT '2016-11-30 18:08:02'::text AS version
$$
