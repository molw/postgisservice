CREATE FUNCTION st_mapalgebrafct (rast1 raster, rast2 raster, tworastuserfunc regprocedure, pixeltype text DEFAULT NULL::text, extenttype text DEFAULT 'INTERSECTION'::text, VARIADIC userargs text[] DEFAULT NULL::text[]) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_mapalgebrafct($1, 1, $2, 1, $3, $4, $5, VARIADIC $6) 
$$
