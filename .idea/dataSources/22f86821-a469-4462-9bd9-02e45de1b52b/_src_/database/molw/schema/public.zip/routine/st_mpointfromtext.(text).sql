CREATE FUNCTION st_mpointfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'MULTIPOINT'
	THEN ST_GeomFromText($1)
	ELSE NULL END
	
$$
