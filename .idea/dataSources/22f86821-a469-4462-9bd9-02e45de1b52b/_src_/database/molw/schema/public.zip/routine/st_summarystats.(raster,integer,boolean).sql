CREATE FUNCTION st_summarystats (rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, $2, $3, 1) 
$$
