CREATE FUNCTION st_distance (geography, geography, boolean) RETURNS double precision
	LANGUAGE sql
AS $$
SELECT _ST_Distance($1, $2, 0.0, $3)
$$
