CREATE FUNCTION st_orderingequals (geometrya geometry, geometryb geometry) RETURNS boolean
	LANGUAGE sql
AS $$
 
	SELECT $1 ~= $2 AND _ST_OrderingEquals($1, $2)
	
$$
